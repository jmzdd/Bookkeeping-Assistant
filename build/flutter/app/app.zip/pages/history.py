import flet as ft

def history_page():
    return ft.Text("历史记录页面")
